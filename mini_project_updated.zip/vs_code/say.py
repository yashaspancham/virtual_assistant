from v1 import lis
say=[]
listen=lis()
say=(input().split(" "))

if(say[0]=="say"):
    say.pop(0)
    y=' '.join(say)
    print(y)
else:
    pass