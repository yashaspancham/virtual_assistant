bits=[]
n=int(input("Enter number of bits"))
for j in range(0,n):
    ele=int(input("Enter the bit"))
    bits.append(ele)
print("Entered bits",bits)
stuffed=[]
count=0
for i in range(len(bits)-1):
    if bits[i]==1:
        count=count+1
        stuffed.append(bits[i])
    elif bits[i]!=1:
        count=0
        stuffed.append(bits[i])
    if count==5:
        stuffed.insert(i+1,0)
        count=0
        
stuffed.append("01111110")
stuffed.insert(0,"01111110")
print("Result after bitstuffing")
for i in stuffed:
    print(i,end="")
c=0
recstu=stuffed[1:-1]
for j in range(len(recstu)-1):
    if recstu[j]==1:
        c=c+1
    elif recstu[j]!=1:
        c=0
    if c==5:
        recstu.pop(j+1)
print("\nBit recieved from Sender")
for i in recstu:
    print(i,end="")