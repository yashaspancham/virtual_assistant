import say


def process(said):
    say.say(said)