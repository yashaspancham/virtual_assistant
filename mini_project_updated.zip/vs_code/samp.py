import speech_recognition as sr
import time
import pyttsx3

r = sr.Recognizer()
engine = pyttsx3.init()

engine.say("how can i help you")