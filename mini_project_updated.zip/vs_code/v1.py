import speech_recognition as sr
import time
import pyttsx3


r = sr.Recognizer()
engine = pyttsx3.init()
def lis():
    with sr.Microphone() as source:
        print("Speak now...")
        audio = r.listen(source, timeout=5, phrase_time_limit=5)
        print("Processing")
        said=r.recognize_google(audio)
        said=str(said)
        return said,audio,r

def speak():
    said,audio,r=lis()
    try:
        print("You said: " + said)
        engine.say("how can i help you")
        engine.runAndWait()
        print(type(said))
        print(type(audio))
        print(type(r))
        
    except sr.UnknownValueError:
        print("Google Speech Recognition could not understand audio")
    except sr.RequestError as e:
        print("Could not request results from Google Speech Recognition service; {0}".format(e))

speak()